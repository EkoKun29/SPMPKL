package com.example.spmpkl.ui_mahasiswa.nilai;

import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.TextView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.spmpkl.R;
import com.example.spmpkl.preferences;

public class MahasiswaNilaiViewModel extends ViewModel {


    public MahasiswaNilaiViewModel() {





    }
    private void gettingData(){



    }

    //public LiveData<String> getText() {
        //return mText;
    }
//}