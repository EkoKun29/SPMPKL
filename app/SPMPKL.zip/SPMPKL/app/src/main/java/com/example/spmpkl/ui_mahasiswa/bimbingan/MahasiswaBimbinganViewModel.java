package com.example.spmpkl.ui_mahasiswa.bimbingan;

import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.TextView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.spmpkl.R;
import com.example.spmpkl.preferences;

public class MahasiswaBimbinganViewModel extends ViewModel {


    public MahasiswaBimbinganViewModel() {





    }
    private void gettingData(){



    }

    //public LiveData<String> getText() {
        //return mText;
    }
//}