package com.example.spmpkl;

public class dataNilai {
    private String key;

    private String Unsur1, Unsur2,Unsur3,Unsur4,Unsur5,Unsur6,Unsur7;
    private int Nilai1, Nilai2, Nilai3,Nilai4,Nilai5,Nilai6,Nilai7;
    private String Keterangan1, Keterangan2, Keterangan3, Keterangan4,Keterangan5,Keterangan6,Keterangan7;

    public dataNilai(){

    }
    public dataNilai(String Unsur1, String Unsur2, String Unsur3, String Unsur4,String Unsur5,
                     String Unsur6,String Unsur7, int Nilai1, int Nilai2, int Nilai3,int Nilai4,
                     int Nilai5,int Nilai6, int Nilai7, String Keterangan1,String  Keterangan2,
                     String Keterangan3, String Keterangan4,String Keterangan5,String Keterangan6,String Keterangan7) {
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getUnsur1() {
        return Unsur1;
    }

    public void setUnsur1(String unsur1) {
        Unsur1 = unsur1;
    }

    public String getUnsur2() {
        return Unsur2;
    }

    public void setUnsur2(String unsur2) {
        Unsur2 = unsur2;
    }

    public String getUnsur3() {
        return Unsur3;
    }

    public void setUnsur3(String unsur3) {
        Unsur3 = unsur3;
    }

    public String getUnsur4() {
        return Unsur4;
    }

    public void setUnsur4(String unsur4) {
        Unsur4 = unsur4;
    }

    public String getUnsur5() {
        return Unsur5;
    }

    public void setUnsur5(String unsur5) {
        Unsur5 = unsur5;
    }

    public String getUnsur6() {
        return Unsur6;
    }

    public void setUnsur6(String unsur6) {
        Unsur6 = unsur6;
    }

    public String getUnsur7() {
        return Unsur7;
    }

    public void setUnsur7(String unsur7) {
        Unsur7 = unsur7;
    }

    public int getNilai1() {
        return Nilai1;
    }

    public void setNilai1(int nilai1) {
        Nilai1 = nilai1;
    }

    public int getNilai2() {
        return Nilai2;
    }

    public void setNilai2(int nilai2) {
        Nilai2 = nilai2;
    }

    public int getNilai3() {
        return Nilai3;
    }

    public void setNilai3(int nilai3) {
        Nilai3 = nilai3;
    }

    public int getNilai4() {
        return Nilai4;
    }

    public void setNilai4(int nilai4) {
        Nilai4 = nilai4;
    }

    public int getNilai5() {
        return Nilai5;
    }

    public void setNilai5(int nilai5) {
        Nilai5 = nilai5;
    }

    public int getNilai6() {
        return Nilai6;
    }

    public void setNilai6(int nilai6) {
        Nilai6 = nilai6;
    }

    public int getNilai7() {
        return Nilai7;
    }

    public void setNilai7(int nilai7) {
        Nilai7 = nilai7;
    }

    public String getKeterangan1() {
        return Keterangan1;
    }

    public void setKeterangan1(String keterangan1) {
        Keterangan1 = keterangan1;
    }

    public String getKeterangan2() {
        return Keterangan2;
    }

    public void setKeterangan2(String keterangan2) {
        Keterangan2 = keterangan2;
    }

    public String getKeterangan3() {
        return Keterangan3;
    }

    public void setKeterangan3(String keterangan3) {
        Keterangan3 = keterangan3;
    }

    public String getKeterangan4() {
        return Keterangan4;
    }

    public void setKeterangan4(String keterangan4) {
        Keterangan4 = keterangan4;
    }

    public String getKeterangan5() {
        return Keterangan5;
    }

    public void setKeterangan5(String keterangan5) {
        Keterangan5 = keterangan5;
    }

    public String getKeterangan6() {
        return Keterangan6;
    }

    public void setKeterangan6(String keterangan6) {
        Keterangan6 = keterangan6;
    }

    public String getKeterangan7() {
        return Keterangan7;
    }

    public void setKeterangan7(String keterangan7) {
        Keterangan7 = keterangan7;
    }
}
