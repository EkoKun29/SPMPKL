package com.example.spmpkl.ui_pelap.nilai_pelap;



import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;


import com.example.spmpkl.Common;
import com.example.spmpkl.DosenActivity;
import com.example.spmpkl.MahasiswaActivity;
import com.example.spmpkl.dataNilai;
import com.example.spmpkl.databinding.PelapFragmentNilaiBinding;
import com.google.ar.core.Config;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.model.Document;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.zip.DataFormatException;

public class NilaiFragment extends Fragment {
    EditText nomor1, unsur1, nilai1, keterangan1,
             nomor2, unsur2, nilai2, keterangan2,
             nomor3, unsur3, nilai3, keterangan3,
             nomor4, unsur4, nilai4, keterangan4,
             nomor5, unsur5, nilai5, keterangan5,
             nomor6, unsur6, nilai6, keterangan6,
             nomor7, unsur7, nilai7, keterangan7;

    Button btn_simpan;




    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users/18670056");


    private PelapFragmentNilaiBinding binding;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = PelapFragmentNilaiBinding.inflate(inflater, container, false);
        nomor1 = binding.no1;
        unsur1 = binding.u1;
        nilai1 = binding.n1;
        keterangan1 = binding.k1;

        nomor2 = binding.no2;
        unsur2 = binding.u2;
        nilai2 = binding.n2;
        keterangan2 = binding.k2;

        nomor3 = binding.no3;
        unsur3 = binding.u3;
        nilai3 = binding.n3;
        keterangan3 = binding.k3;

        nomor4 = binding.no4;
        unsur4 = binding.u4;
        nilai4 = binding.n4;
        keterangan4 = binding.k4;

        nomor5 = binding.no5;
        unsur5 = binding.u5;
        nilai5 = binding.n5;
        keterangan5 = binding.k5;

        nomor6 = binding.no6;
        unsur6 = binding.u6;
        nilai6 = binding.n6;
        keterangan6 = binding.k6;

        nomor7 = binding.no7;
        unsur7 = binding.u7;
        nilai7 = binding.n7;
        keterangan7 = binding.k7;

        btn_simpan = binding.simpan;


        Intent intent = getActivity().getIntent();
        String m_name = intent.getStringExtra("Ppkl1");





        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String Unsur1 = unsur1.getText().toString();
                String Unsur2 = unsur2.getText().toString();
                String Unsur3 = unsur3.getText().toString();
                String Unsur4 = unsur4.getText().toString();
                String Unsur5 = unsur5.getText().toString();
                String Unsur6 = unsur6.getText().toString();
                String Unsur7 = unsur7.getText().toString();

                String Nilai1 = nilai1.getText().toString();
                String Nilai2 = nilai2.getText().toString();
                String Nilai3 = nilai3.getText().toString();
                String Nilai4 = nilai4.getText().toString();
                String Nilai5 = nilai5.getText().toString();
                String Nilai6 = nilai6.getText().toString();
                String Nilai7 = nilai7.getText().toString();

                String Keterangan1 = keterangan1.getText().toString();
                String Keterangan2 = keterangan2.getText().toString();
                String Keterangan3 = keterangan3.getText().toString();
                String Keterangan4 = keterangan4.getText().toString();
                String Keterangan5 = keterangan5.getText().toString();
                String Keterangan6 = keterangan6.getText().toString();
                String Keterangan7 = keterangan7.getText().toString();

                if (Unsur1.isEmpty() || Unsur2.isEmpty() || Unsur3.isEmpty() || Unsur4.isEmpty() || Unsur5.isEmpty() || Unsur6.isEmpty() || Unsur7.isEmpty()
                        || Nilai1.isEmpty() || Nilai2.isEmpty() || Nilai3.isEmpty() || Nilai4.isEmpty() || Nilai5.isEmpty() || Nilai6.isEmpty() || Nilai7.isEmpty() ||
                        Keterangan1.isEmpty() || Keterangan2.isEmpty() || Keterangan3.isEmpty() || Keterangan4.isEmpty() || Keterangan5.isEmpty() || Keterangan6.isEmpty() || Keterangan7.isEmpty()) {
                    Toast.makeText(NilaiFragment.this.getActivity(), "Data Tidak Boleh Kosong!!", Toast.LENGTH_SHORT).show();
                } else {


                  /*  int N1 = Integer.parseInt(Nilai1);
                    int N2 = Integer.parseInt(Nilai2);
                    int N3 = Integer.parseInt(Nilai3);
                    int N4 = Integer.parseInt(Nilai4);
                    int N5 = Integer.parseInt(Nilai5);
                    int N6 = Integer.parseInt(Nilai6);
                    int N7 = Integer.parseInt(Nilai7);*/
                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            databaseReference.child("unsur1").setValue(Unsur1);
                            databaseReference.child("unsur2").setValue(Unsur2);
                            databaseReference.child("unsur3").setValue(Unsur3);
                            databaseReference.child("unsur4").setValue(Unsur4);
                            databaseReference.child("unsur5").setValue(Unsur5);
                            databaseReference.child("unsur6").setValue(Unsur6);
                            databaseReference.child("unsur7").setValue(Unsur7);

                            databaseReference.child("nilai1").setValue(Nilai1);
                            databaseReference.child("nilai2").setValue(Nilai2);
                            databaseReference.child("nilai3").setValue(Nilai3);
                            databaseReference.child("nilai4").setValue(Nilai4);
                            databaseReference.child("nilai5").setValue(Nilai5);
                            databaseReference.child("nilai6").setValue(Nilai6);
                            databaseReference.child("nilai7").setValue(Nilai7);

                            databaseReference.child("keterangan1").setValue(Keterangan1);
                            databaseReference.child("keterangan2").setValue(Keterangan2);
                            databaseReference.child("keterangan3").setValue(Keterangan3);
                            databaseReference.child("keterangan4").setValue(Keterangan4);
                            databaseReference.child("keterangan5").setValue(Keterangan5);
                            databaseReference.child("keterangan6").setValue(Keterangan6);
                            databaseReference.child("keterangan7").setValue(Keterangan7);

                            Toast.makeText(requireContext(), "Data Berhasil DiKirim", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                                /*@Override
                                public void onSuccess(Void aVoid) {
                                    databaseReference.child("rekapNilai").child(m_name).child("unsur1").setValue(Unsur1);
                                    Toast.makeText(requireContext(), "Data Berhasil Disimpan", Toast.LENGTH_SHORT).show();

                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(requireContext(), "Data Gagal Disimpan", Toast.LENGTH_SHORT).show();
                                }
                            });*/
                }


            }

        });





       /* dataShow();*/
        View view = binding.getRoot();


        return view;
    }

    /*public Bitmap getBitmapFromView(View view, int totalHeight, int totalWidth){

        Bitmap returnedBitmap = Bitmap.createBitmap(totalWidth,totalHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        Drawable bgDrawable = view.getBackground();
        if(bgDrawable != null){
            bgDrawable.draw(canvas);
        }else{
            canvas.drawColor(Color.WHITE);
        }
        view.draw(canvas);
        return returnedBitmap;
    }
    private void takeScreenShot(){
        File folder = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Rekap Nilai/");
        if(!folder.exists()){
            boolean success = folder.mkdir();
        }
        path = folder.getAbsolutePath();
        path = path+"/" + file_name + System.currentTimeMillis() + ".pdf";

        View v = binding.rekap;
        ScrollView sv = binding.rekap;
        totalHeight = sv.getChildAt(0).getHeight();
        totalWidth = sv.getChildAt(0).getWidth();

        String extr = Environment.getExternalStorageDirectory() +"/Nilai/";
        File file = new File(extr);
        if(!file.exists()){
            file.mkdir();
            String fileName = file_name +".jpg";
            myPath = new File(extr, fileName);
            imageUri = myPath.getPath();
            bitmap = String.valueOf(getBitmapFromView(v, totalHeight, totalWidth));

            try{
                FileOutputStream fos = new FileOutputStream(myPath);
                *//*bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);*//*
                fos.flush();
                fos.close();
            }catch (Exception e){
                e.printStackTrace();
            }
          *//*  createPdf();*//*
        }
    }*/
   /* private void createPdf(){
        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(bitmap.getWidth(), bitmap.getHeight(), 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        paint.setColor(Color.parseColor("#ffffff"));
        canvas.drawPaint(paint);

        Bitmap bitmap = Bitmap.createScaledBitmap(this.bitmap, this.bitmap.getWidth(), this.bitmap.getHeight(), true);

        paint.setColor(Color.BLUE);
        canvas.drawBitmap(bitmap, 0, 0, null);
        document.finishPage(page);
        File filePath = new File(path);
        try{
            document.writeTo(new FileOutputStream(filePath));
        }catch(IOException e){
            e.printStackTrace();
            Toast.makeText(requireContext(), "Something Wrong:"+e.toString(), Toast.LENGTH_SHORT).show();
        }
        document.close();
        if(myPath.exists()){
            myPath.delete();
            openPdf(path);
        }
        
    }
private void openPdf(String path){
        File file = new File(path);
        Intent target = new Intent(Intent.ACTION_VIEW);
        target.setDataAndType(Uri.fromFile(file), "application/pdf");
        target.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);

        Intent intent = Intent.createChooser(target, "Open File");
        try{
            startActivity(intent);
        }catch(ActivityNotFoundException e){
            Toast.makeText(requireContext(), "No Apps to read PDF File", Toast.LENGTH_SHORT).show();
        }
}
*/


  /*  private void dataShow(){
        databaseReference.child("rekapNilai").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listNilai.clear();
                for(DataSnapshot data : snapshot.getChildren()){
                    dataNilai nilai = data.getValue(dataNilai.class);
                    nilai.setKey(data.getKey());
                    listNilai.add(nilai);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }*/


    /*private Dialog getDialog() {
        return dialog;
    }*/


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;

    }


}