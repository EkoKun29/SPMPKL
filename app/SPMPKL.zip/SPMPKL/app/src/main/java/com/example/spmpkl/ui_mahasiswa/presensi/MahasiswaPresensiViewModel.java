package com.example.spmpkl.ui_mahasiswa.presensi;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MahasiswaPresensiViewModel extends ViewModel {
/*
    private final MutableLiveData<String> mText;

    public MahasiswaPresensiViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is gallery fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }*/
}